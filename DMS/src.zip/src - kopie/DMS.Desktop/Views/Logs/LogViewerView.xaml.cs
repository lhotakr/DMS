﻿using DMS.Desktop.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Xml;

namespace DMS.Desktop.Views.Logs;

public partial class LogViewerView : UserControl
{
    private readonly string _logsRootPath;
    private readonly DmsLogReader _logReader;
    private readonly Func<string, string> _translate;
    private readonly Func<string, object[], string> _translateFormat;
    private readonly Action<string, string> _logAction;
    private readonly string _cultureName;

    private IReadOnlyList<DmsLogEntry> _currentEntries = Array.Empty<DmsLogEntry>();

    public LogViewerView(
        string logsRootPath,
        DmsLogReader logReader,
        Func<string, string> translate,
        Func<string, object[], string> translateFormat,
        Action<string, string> logAction,
        string cultureName)
    {
        InitializeComponent();

        _logsRootPath = logsRootPath;
        _logReader = logReader ?? throw new ArgumentNullException(nameof(logReader));
        _translate = translate ?? throw new ArgumentNullException(nameof(translate));
        _translateFormat = translateFormat ?? throw new ArgumentNullException(nameof(translateFormat));
        _logAction = logAction ?? throw new ArgumentNullException(nameof(logAction));
        _cultureName = string.IsNullOrWhiteSpace(cultureName)
            ? CultureInfo.CurrentUICulture.Name
            : cultureName;

        ConfigureDatePicker();
        ConfigureGrid();
        LoadLevels();
        ApplyLocalization();
        HookFilterShortcuts();

        DateLogDay.SelectedDate = DateTime.Today;

        RefreshLog(writeLog: false);
        UpdateDetailPanel();
    }

    private string T(string key, string fallback)
    {
        var value = _translate(key);

        if (string.IsNullOrWhiteSpace(value) ||
            string.Equals(value, key, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(value, $"[[{key}]]", StringComparison.OrdinalIgnoreCase))
        {
            return fallback;
        }

        return value;
    }

    private string TF(string key, string fallback, params object[] args)
    {
        var value = _translateFormat(key, args);

        if (string.IsNullOrWhiteSpace(value) ||
            string.Equals(value, key, StringComparison.OrdinalIgnoreCase) ||
            string.Equals(value, $"[[{key}]]", StringComparison.OrdinalIgnoreCase))
        {
            return string.Format(CultureInfo.CurrentCulture, fallback, args);
        }

        return value;
    }

    private void ApplyLocalization()
    {
        TxtTitle.Text = T("LOG03.Title", "LOG03 - Application log");
        TxtSubtitle.Text = T("LOG03.Subtitle", "Structured application log overview.");

        LblDay.Text = T("LOG03.Filter.Day", "Day:");
        LblFrom.Text = T("LOG03.Filter.From", "From:");
        LblTo.Text = T("LOG03.Filter.To", "To:");
        LblLevel.Text = T("LOG03.Filter.Level", "Level:");
        LblUser.Text = T("LOG03.Filter.User", "User:");
        LblText.Text = T("LOG03.Filter.Text", "Text:");

        TxtTimeFrom.ToolTip = T("LOG03.Tooltip.From", "Time from, for example 08:00");
        TxtTimeTo.ToolTip = T("LOG03.Tooltip.To", "Time to, for example 16:30");
        TxtUser.ToolTip = T("LOG03.Tooltip.User", "User filter, for example Radek");
        TxtText.ToolTip = T("LOG03.Tooltip.Text", "Searches in summary, detail, action, user and raw line");

        BtnRefresh.Content = T("LOG03.Button.Filter", "Filter");
        BtnCopyRaw.Content = T("LOG03.Button.CopyRaw", "Copy raw");
        BtnClearSelection.Content = T("LOG03.Button.ClearSelection", "Clear selection");

        TxtDetailTitle.Text = T("LOG03.Detail.Title", "Selected log entry");

        RefreshGridHeaders();
        RefreshLevelAllText();
    }

    private void ConfigureDatePicker()
    {
        DateLogDay.Language = XmlLanguage.GetLanguage(_cultureName);
        DateLogDay.CalendarStyle = CreateLogCalendarStyle();

        DateLogDay.Resources[typeof(DatePickerTextBox)] = CreateLogDatePickerTextBoxStyle();

        DateLogDay.Loaded += (_, _) => ApplyDatePickerTextBoxColors(DateLogDay);
        DateLogDay.SelectedDateChanged += (_, _) =>
        {
            ApplyDatePickerTextBoxColors(DateLogDay);
            RefreshLog(writeLog: false);
        };

        DateLogDay.CalendarOpened += (_, _) =>
        {
            Dispatcher.BeginInvoke(
                new Action(() => ApplyDatePickerPopupColors(DateLogDay)),
                System.Windows.Threading.DispatcherPriority.Loaded);
        };
    }

    private void HookFilterShortcuts()
    {
        TxtTimeFrom.KeyDown += FilterTextBox_KeyDown;
        TxtTimeTo.KeyDown += FilterTextBox_KeyDown;
        TxtUser.KeyDown += FilterTextBox_KeyDown;
        TxtText.KeyDown += FilterTextBox_KeyDown;

        CmbLevel.SelectionChanged += (_, _) =>
        {
            if (CmbLevel.IsLoaded)
            {
                RefreshLog(writeLog: false);
            }
        };
    }

    private void FilterTextBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter)
        {
            return;
        }

        e.Handled = true;
        RefreshLog(writeLog: true);
    }

    private void LoadLevels()
    {
        CmbLevel.Items.Clear();

        CmbLevel.Items.Add(new ComboBoxItem
        {
            Content = T("LOG03.Level.All", "All"),
            Tag = string.Empty
        });

        foreach (var level in new[]
                 {
                     "INFO",
                     "WARN",
                     "ERROR",
                     "APP",
                     "TRANSACTION",
                     "TX_START",
                     "TX_OK",
                     "TX_ERROR",
                     "TX_DENIED",
                     "TX_VALIDATION",
                     "ADMIN",
                     "AUDIT",
                     "AUDIT_CREATE",
                     "AUDIT_DELETE",
                     "DATA",
                     "DOCUMENT"
                 })
        {
            CmbLevel.Items.Add(new ComboBoxItem
            {
                Content = level,
                Tag = level
            });
        }

        CmbLevel.SelectedIndex = 0;
    }

    private void RefreshLevelAllText()
    {
        if (CmbLevel.Items.Count > 0 &&
            CmbLevel.Items[0] is ComboBoxItem allItem)
        {
            allItem.Content = T("LOG03.Level.All", "All");
        }
    }

    private void ConfigureGrid()
    {
        GridLogEntries.RowStyle = CreateLogRowStyle();
        GridLogEntries.CellStyle = CreateLogCellStyle();
        GridLogEntries.ColumnHeaderStyle = CreateLogColumnHeaderStyle();

        GridLogEntries.Columns.Clear();

        GridLogEntries.Columns.Add(CreateLogTextColumn("Time", nameof(DmsLogEntry.TimestampText), 95));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Level", nameof(DmsLogEntry.Level), 105));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Summary", nameof(DmsLogEntry.HumanText), 320));
        GridLogEntries.Columns.Add(CreateLogTextColumn("User", nameof(DmsLogEntry.User), 170));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Area", nameof(DmsLogEntry.Area), 90));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Action", nameof(DmsLogEntry.Action), 210));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Detail", nameof(DmsLogEntry.Detail), 520));
        GridLogEntries.Columns.Add(CreateLogTextColumn("Duration ms", nameof(DmsLogEntry.DurationMs), 90));

        GridLogEntries.LoadingRow += (_, e) =>
        {
            if (e.Row.Item is DmsLogEntry entry)
            {
                e.Row.ToolTip = entry.RawLine;
            }
        };
    }

    private void RefreshGridHeaders()
    {
        if (GridLogEntries.Columns.Count < 8)
        {
            return;
        }

        GridLogEntries.Columns[0].Header = T("LOG03.Column.Time", "Time");
        GridLogEntries.Columns[1].Header = T("LOG03.Column.Level", "Level");
        GridLogEntries.Columns[2].Header = T("LOG03.Column.Summary", "Summary");
        GridLogEntries.Columns[3].Header = T("LOG03.Column.User", "User");
        GridLogEntries.Columns[4].Header = T("LOG03.Column.Area", "Area");
        GridLogEntries.Columns[5].Header = T("LOG03.Column.Action", "Action");
        GridLogEntries.Columns[6].Header = T("LOG03.Column.Detail", "Detail");
        GridLogEntries.Columns[7].Header = T("LOG03.Column.DurationMs", "Duration ms");
    }

    private void RefreshLog(bool writeLog)
    {
        var day = DateLogDay.SelectedDate ?? DateTime.Today;
        var entries = _logReader.ReadDay(_logsRootPath, day);

        if (TryParseTime(TxtTimeFrom.Text, out var timeFrom))
        {
            entries = entries
                .Where(item => item.Timestamp.TimeOfDay >= timeFrom)
                .ToList();
        }

        if (TryParseTime(TxtTimeTo.Text, out var timeTo))
        {
            entries = entries
                .Where(item => item.Timestamp.TimeOfDay <= timeTo)
                .ToList();
        }

        var selectedLevel = (CmbLevel.SelectedItem as ComboBoxItem)?.Tag?.ToString();

        if (!string.IsNullOrWhiteSpace(selectedLevel))
        {
            entries = entries
                .Where(item => string.Equals(item.Level, selectedLevel, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        var userFilter = TxtUser.Text.Trim();

        if (!string.IsNullOrWhiteSpace(userFilter))
        {
            entries = entries
                .Where(item =>
                    ContainsAny(item.User, userFilter) ||
                    ContainsAny(item.Roles, userFilter))
                .ToList();
        }

        var textFilter = TxtText.Text.Trim();

        if (!string.IsNullOrWhiteSpace(textFilter))
        {
            entries = entries
                .Where(item =>
                    ContainsAny(item.HumanText, textFilter) ||
                    ContainsAny(item.Area, textFilter) ||
                    ContainsAny(item.Action, textFilter) ||
                    ContainsAny(item.Entity, textFilter) ||
                    ContainsAny(item.EntityId, textFilter) ||
                    ContainsAny(item.Field, textFilter) ||
                    ContainsAny(item.OldValue, textFilter) ||
                    ContainsAny(item.NewValue, textFilter) ||
                    ContainsAny(item.Reason, textFilter) ||
                    ContainsAny(item.Detail, textFilter) ||
                    ContainsAny(item.Message, textFilter) ||
                    ContainsAny(item.RawLine, textFilter))
                .ToList();
        }

        _currentEntries = entries;
        GridLogEntries.ItemsSource = _currentEntries;

        TxtSubtitle.Text = TF(
            "LOG03.SubtitleFormat",
            "Structured application log overview. Displayed records: {0}. Log root: {1}",
            _currentEntries.Count,
            _logsRootPath);

        TxtStatus.Text = TF("LOG03.Status.Loaded", "Loaded records: {0}", _currentEntries.Count);

        UpdateDetailPanel();

        if (writeLog)
        {
            _logAction(
                "RefreshLogViewer",
                BuildFilterDetail(_currentEntries.Count));
        }
    }

    private string BuildFilterDetail(int loadedRows)
    {
        var selectedLevel = (CmbLevel.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? string.Empty;

        return
            $"Date={DateLogDay.SelectedDate:yyyy-MM-dd}; " +
            $"From={TxtTimeFrom.Text.Trim()}; " +
            $"To={TxtTimeTo.Text.Trim()}; " +
            $"Level={selectedLevel}; " +
            $"UserFilter={TxtUser.Text.Trim()}; " +
            $"TextFilter={TxtText.Text.Trim()}; " +
            $"LoadedRows={loadedRows}";
    }

    private void BtnRefresh_Click(object sender, RoutedEventArgs e)
    {
        RefreshLog(writeLog: true);
    }

    private void BtnCopyRaw_Click(object sender, RoutedEventArgs e)
    {
        var selectedEntries = GridLogEntries.SelectedItems
            .OfType<DmsLogEntry>()
            .Select(item => item.RawLine)
            .Where(line => !string.IsNullOrWhiteSpace(line))
            .ToList();

        if (selectedEntries.Count == 0 && GridLogEntries.SelectedItem is DmsLogEntry entry)
        {
            selectedEntries.Add(entry.RawLine);
        }

        if (selectedEntries.Count == 0)
        {
            TxtStatus.Text = T("LOG03.Status.SelectRowsToCopy", "Select one or more rows to copy.");
            return;
        }

        Clipboard.SetText(string.Join(Environment.NewLine, selectedEntries));

        TxtStatus.Text = TF("LOG03.Status.Copied", "Copied raw log lines: {0}", selectedEntries.Count);

        _logAction(
            "CopyRawLogLines",
            $"CopiedRows={selectedEntries.Count}");
    }

    private void BtnClearSelection_Click(object sender, RoutedEventArgs e)
    {
        GridLogEntries.SelectedItems.Clear();
        UpdateDetailPanel();
    }

    private void GridLogEntries_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdateDetailPanel();
    }

    private void UpdateDetailPanel()
    {
        var selectedEntries = GridLogEntries.SelectedItems
            .OfType<DmsLogEntry>()
            .ToList();

        if (selectedEntries.Count == 0)
        {
            TxtDetail.Text = T("LOG03.Detail.NoSelection", "Select a log entry to show details.");
            return;
        }

        if (selectedEntries.Count > 1)
        {
            TxtDetail.Text = TF("LOG03.Detail.MultipleSelection", "Selected log entries: {0}", selectedEntries.Count);
            return;
        }

        var entry = selectedEntries[0];

        TxtDetail.Text =
            $"{T("LOG03.Detail.Timestamp", "Timestamp")}: {entry.Timestamp:yyyy-MM-dd HH:mm:ss.fff}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Level", "Level")}: {entry.Level}{Environment.NewLine}" +
            $"{T("LOG03.Detail.OperationId", "Operation ID")}: {entry.OperationId}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Code", "Code")}: {entry.Code}{Environment.NewLine}" +
            $"{T("LOG03.Detail.User", "User")}: {entry.User}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Roles", "Roles")}: {entry.Roles}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Area", "Area")}: {entry.Area}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Action", "Action")}: {entry.Action}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Entity", "Entity")}: {entry.Entity}{Environment.NewLine}" +
            $"{T("LOG03.Detail.EntityId", "Entity ID")}: {entry.EntityId}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Field", "Field")}: {entry.Field}{Environment.NewLine}" +
            $"{T("LOG03.Detail.OldValue", "Old value")}: {entry.OldValue}{Environment.NewLine}" +
            $"{T("LOG03.Detail.NewValue", "New value")}: {entry.NewValue}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Reason", "Reason")}: {entry.Reason}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Detail", "Detail")}: {entry.Detail}{Environment.NewLine}" +
            $"{T("LOG03.Detail.Message", "Message")}: {entry.Message}{Environment.NewLine}" +
            $"{T("LOG03.Detail.RawLine", "Raw line")}: {entry.RawLine}";
    }

    private static bool TryParseTime(string value, out TimeSpan time)
    {
        if (TimeSpan.TryParse(value.Trim(), CultureInfo.InvariantCulture, out time))
        {
            return true;
        }

        if (TimeSpan.TryParse(value.Trim(), CultureInfo.CurrentCulture, out time))
        {
            return true;
        }

        time = TimeSpan.Zero;
        return false;
    }

    private static DataGridTextColumn CreateLogTextColumn(
        string header,
        string bindingPath,
        double width)
    {
        var elementStyle = new Style(typeof(TextBlock));

        elementStyle.Setters.Add(new Setter(TextBlock.TextTrimmingProperty, TextTrimming.CharacterEllipsis));
        elementStyle.Setters.Add(new Setter(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center));
        elementStyle.Setters.Add(new Setter(TextBlock.MarginProperty, new Thickness(6, 0, 6, 0)));

        elementStyle.Setters.Add(new Setter(
            TextBlock.ForegroundProperty,
            new Binding("Foreground")
            {
                RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(DataGridRow), 1)
            }));

        return new DataGridTextColumn
        {
            Header = header,
            Binding = new Binding(bindingPath),
            Width = new DataGridLength(width),
            ElementStyle = elementStyle
        };
    }

    private static Style CreateLogRowStyle()
    {
        var style = new Style(typeof(DataGridRow));

        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0)));
        style.Setters.Add(new Setter(FrameworkElement.MinHeightProperty, 26.0));
        style.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));

        AddLogRowBackgroundTrigger(style, "TX_OK", Color.FromRgb(28, 55, 34));
        AddLogRowBackgroundTrigger(style, "AUDIT_CREATE", Color.FromRgb(28, 55, 34));

        AddLogRowBackgroundTrigger(style, "WARN", Color.FromRgb(74, 56, 32));
        AddLogRowBackgroundTrigger(style, "TX_VALIDATION", Color.FromRgb(74, 56, 32));
        AddLogRowBackgroundTrigger(style, "AUDIT", Color.FromRgb(74, 56, 32));

        AddLogRowBackgroundTrigger(style, "ERROR", Color.FromRgb(74, 32, 32));
        AddLogRowBackgroundTrigger(style, "TX_ERROR", Color.FromRgb(74, 32, 32));
        AddLogRowBackgroundTrigger(style, "TX_DENIED", Color.FromRgb(74, 32, 32));
        AddLogRowBackgroundTrigger(style, "AUDIT_DELETE", Color.FromRgb(74, 32, 32));

        AddLogRowBackgroundTrigger(style, "ADMIN", Color.FromRgb(36, 48, 68));
        AddLogRowBackgroundTrigger(style, "APP", Color.FromRgb(36, 48, 68));
        AddLogRowBackgroundTrigger(style, "DOCUMENT", Color.FromRgb(36, 48, 68));
        AddLogRowBackgroundTrigger(style, "DATA", Color.FromRgb(36, 48, 68));

        AddLogRowBackgroundTrigger(style, "TX_START", Color.FromRgb(39, 39, 42));
        AddLogRowBackgroundTrigger(style, "TRANSACTION", Color.FromRgb(39, 39, 42));
        AddLogRowBackgroundTrigger(style, "INFO", Color.FromRgb(39, 39, 42));

        var mouseOverTrigger = new Trigger
        {
            Property = UIElement.IsMouseOverProperty,
            Value = true
        };

        mouseOverTrigger.Setters.Add(new Setter(
            Control.ForegroundProperty,
            new SolidColorBrush(Color.FromRgb(255, 229, 0))));

        mouseOverTrigger.Setters.Add(new Setter(
            Control.BackgroundProperty,
            new SolidColorBrush(Color.FromRgb(62, 58, 24))));

        style.Triggers.Add(mouseOverTrigger);

        var selectedTrigger = new Trigger
        {
            Property = Selector.IsSelectedProperty,
            Value = true
        };

        selectedTrigger.Setters.Add(new Setter(
            Control.ForegroundProperty,
            new SolidColorBrush(Color.FromRgb(255, 229, 0))));

        selectedTrigger.Setters.Add(new Setter(
            Control.BackgroundProperty,
            new SolidColorBrush(Color.FromRgb(36, 58, 92))));

        style.Triggers.Add(selectedTrigger);

        return style;
    }

    private static void AddLogRowBackgroundTrigger(
        Style style,
        string level,
        Color color)
    {
        var trigger = new DataTrigger
        {
            Binding = new Binding(nameof(DmsLogEntry.Level)),
            Value = level
        };

        trigger.Setters.Add(new Setter(
            Control.BackgroundProperty,
            new SolidColorBrush(color)));

        style.Triggers.Add(trigger);
    }

    private static Style CreateLogCellStyle()
    {
        var style = new Style(typeof(DataGridCell));

        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0)));
        style.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));

        var selectedTrigger = new Trigger
        {
            Property = Selector.IsSelectedProperty,
            Value = true
        };

        selectedTrigger.Setters.Add(new Setter(Control.BackgroundProperty, Brushes.Transparent));
        selectedTrigger.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.Transparent));
        selectedTrigger.Setters.Add(new Setter(Control.ForegroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));

        style.Triggers.Add(selectedTrigger);

        var mouseOverTrigger = new Trigger
        {
            Property = UIElement.IsMouseOverProperty,
            Value = true
        };

        mouseOverTrigger.Setters.Add(new Setter(Control.ForegroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Triggers.Add(mouseOverTrigger);

        return style;
    }

    private static Style CreateLogColumnHeaderStyle()
    {
        var style = new Style(typeof(DataGridColumnHeader));

        style.Setters.Add(new Setter(Control.HeightProperty, 34.0));
        style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(8, 0, 8, 0)));
        style.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.Bold));
        style.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Left));
        style.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(18, 18, 18))));
        style.Setters.Add(new Setter(Control.ForegroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(70, 70, 60))));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(0, 0, 1, 1)));

        var mouseOverTrigger = new Trigger
        {
            Property = UIElement.IsMouseOverProperty,
            Value = true
        };

        mouseOverTrigger.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(45, 43, 24))));
        mouseOverTrigger.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));

        style.Triggers.Add(mouseOverTrigger);

        return style;
    }

    private static Style CreateLogDatePickerTextBoxStyle()
    {
        var style = new Style(typeof(DatePickerTextBox));

        style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(10, 10, 10))));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(70, 70, 60))));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(8, 0, 8, 0)));
        style.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Center));
        style.Setters.Add(new Setter(TextBox.SelectionBrushProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Setters.Add(new Setter(TextBox.SelectionTextBrushProperty, Brushes.Black));

        return style;
    }

    private static Style CreateLogCalendarStyle()
    {
        var style = new Style(typeof(System.Windows.Controls.Calendar));

        style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(18, 18, 18))));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(70, 70, 60))));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        style.Setters.Add(new Setter(FrameworkElement.WidthProperty, 280.0));

        style.Resources[typeof(CalendarDayButton)] = CreateLogCalendarDayButtonStyle();
        style.Resources[typeof(CalendarButton)] = CreateLogCalendarButtonStyle();

        return style;
    }

    private static Style CreateLogCalendarDayButtonStyle()
    {
        var style = new Style(typeof(CalendarDayButton));

        style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(18, 18, 18))));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.Transparent));
        style.Setters.Add(new Setter(Control.BorderThicknessProperty, new Thickness(1)));
        style.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.SemiBold));
        style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(4)));

        var mouseOverTrigger = new Trigger
        {
            Property = UIElement.IsMouseOverProperty,
            Value = true
        };

        mouseOverTrigger.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(62, 58, 24))));
        mouseOverTrigger.Setters.Add(new Setter(Control.ForegroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        mouseOverTrigger.Setters.Add(new Setter(Control.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Triggers.Add(mouseOverTrigger);

        var selectedTrigger = new Trigger
        {
            Property = CalendarDayButton.IsSelectedProperty,
            Value = true
        };

        selectedTrigger.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        selectedTrigger.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.Black));
        selectedTrigger.Setters.Add(new Setter(Control.BorderBrushProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Triggers.Add(selectedTrigger);

        var inactiveTrigger = new Trigger
        {
            Property = CalendarDayButton.IsInactiveProperty,
            Value = true
        };

        inactiveTrigger.Setters.Add(new Setter(UIElement.OpacityProperty, 0.35));
        style.Triggers.Add(inactiveTrigger);

        return style;
    }

    private static Style CreateLogCalendarButtonStyle()
    {
        var style = new Style(typeof(CalendarButton));

        style.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(18, 18, 18))));
        style.Setters.Add(new Setter(Control.ForegroundProperty, Brushes.White));
        style.Setters.Add(new Setter(Control.BorderBrushProperty, Brushes.Transparent));
        style.Setters.Add(new Setter(Control.FontWeightProperty, FontWeights.Bold));
        style.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(4)));

        var mouseOverTrigger = new Trigger
        {
            Property = UIElement.IsMouseOverProperty,
            Value = true
        };

        mouseOverTrigger.Setters.Add(new Setter(Control.BackgroundProperty, new SolidColorBrush(Color.FromRgb(62, 58, 24))));
        mouseOverTrigger.Setters.Add(new Setter(Control.ForegroundProperty, new SolidColorBrush(Color.FromRgb(255, 229, 0))));
        style.Triggers.Add(mouseOverTrigger);

        return style;
    }

    private static void ApplyDatePickerTextBoxColors(DependencyObject parent)
    {
        if (parent is DatePickerTextBox datePickerTextBox)
        {
            datePickerTextBox.Background = new SolidColorBrush(Color.FromRgb(10, 10, 10));
            datePickerTextBox.Foreground = Brushes.White;
            datePickerTextBox.BorderBrush = new SolidColorBrush(Color.FromRgb(70, 70, 60));
            datePickerTextBox.SelectionBrush = new SolidColorBrush(Color.FromRgb(255, 229, 0));
            datePickerTextBox.SelectionTextBrush = Brushes.Black;
            datePickerTextBox.Padding = new Thickness(8, 0, 8, 0);
            datePickerTextBox.VerticalContentAlignment = VerticalAlignment.Center;
            datePickerTextBox.MinWidth = 120;
            return;
        }

        var count = VisualTreeHelper.GetChildrenCount(parent);

        for (var index = 0; index < count; index++)
        {
            ApplyDatePickerTextBoxColors(VisualTreeHelper.GetChild(parent, index));
        }
    }

    private static void ApplyDatePickerPopupColors(DependencyObject parent)
    {
        if (parent is TextBlock textBlock)
        {
            textBlock.Foreground = Brushes.White;
        }

        if (parent is CalendarDayButton dayButton)
        {
            dayButton.Foreground = Brushes.White;
        }

        if (parent is CalendarButton calendarButton)
        {
            calendarButton.Foreground = Brushes.White;
        }

        if (parent is System.Windows.Controls.Calendar calendar)
        {
            calendar.Background = new SolidColorBrush(Color.FromRgb(18, 18, 18));
            calendar.Foreground = Brushes.White;
            calendar.BorderBrush = new SolidColorBrush(Color.FromRgb(70, 70, 60));
        }

        var count = VisualTreeHelper.GetChildrenCount(parent);

        for (var index = 0; index < count; index++)
        {
            ApplyDatePickerPopupColors(VisualTreeHelper.GetChild(parent, index));
        }
    }

    private static bool ContainsAny(string? value, string filter)
    {
        return value?.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0;
    }
}
