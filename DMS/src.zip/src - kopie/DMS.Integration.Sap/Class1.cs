﻿namespace DMS.Integration.Sap
{
    public class Class1
    {

    }
}
